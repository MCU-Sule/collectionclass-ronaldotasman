module com.example.pbo2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.pbo2 to javafx.fxml;
    exports com.example.pbo2;
}