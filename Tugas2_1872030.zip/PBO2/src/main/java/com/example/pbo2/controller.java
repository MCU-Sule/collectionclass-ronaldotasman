package com.example.pbo2;

import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class controller {
    public TextField ipnrp;
    public Button carinrp;
    public Button hapusmurid;
    public TextField ipnama;
    public Button tambahmurid;
    public TableView tableview1;
    public TableColumn kolomnrp;
    public TableColumn kolomnama;

    private ObservableList<Integer> onrp;

    public void setcarinrp(ActionEvent actionEvent) {

    }

    public void sethapusmurid(ActionEvent actionEvent) {
    }

    public void settambahmurid(ActionEvent actionEvent) {
        onrp = FXCollections.observableArrayList();
        onrp.add(1972005);
        onrp.add(2072030);
        onrp.add(1872030);

        tableview1.setItems(onrp);
    }

}